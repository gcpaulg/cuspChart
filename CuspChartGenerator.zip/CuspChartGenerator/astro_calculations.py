# astro_calculations.py

from datetime import datetime, timedelta
import collections
from vedicastro.VedicAstro import VedicHoroscopeData
from config import VIMSHOTTARI_DASHAS, ZODIAC_MAP, TITHI_NAMES, KARANA_NAMES, YOGA_NAMES, VARNA_MAP, VASYA_MAP, YONI_MAP, DEFAULT_TIMEZONE

def compute_vimshottari_dasha(moon_longitude, birth_date_str):
    """
    Compute Vimshottari Maha Dasha and Antardasha from Moon longitude.
    Returns: list of dicts with MahaDasha, AntarDasha, Start, End
    """
    dashas = VIMSHOTTARI_DASHAS

    # Determine Nakshatra index (27 Nakshatras)
    nak_index = int((moon_longitude % 360) // (360 / 27))
    dasha_index = nak_index % 9  # Determine starting Dasha planet

    # Start from birth date
    birth_date = datetime.strptime(birth_date_str, "%Y-%m-%d")
    current_maha_start = birth_date

    # Full 120-year cycle Maha Dasha list
    maha_dasha_list = []
    for i in range(9):
        planet, years = dashas[dasha_index]
        start = current_maha_start
        end = start + timedelta(days=years * 365.25)
        maha_dasha_list.append((planet, years, start, end))
        current_maha_start = end
        dasha_index = (dasha_index + 1) % 9

    # --- Build Maha & Antar Dasha table ---
    dasha_data = []
    for maha_planet, maha_years, maha_start, maha_end in maha_dasha_list:
        # Find index of Maha planet to order Antardasha sequence
        maha_index = [p for p, _ in dashas].index(maha_planet)
        antar_sequence = dashas[maha_index:] + dashas[:maha_index]

        antar_start = maha_start
        for antar_planet, antar_years in antar_sequence:
            antar_duration = maha_years * antar_years / 120  # proportional duration
            antar_end = antar_start + timedelta(days=antar_duration * 365.25)
            dasha_data.append({
                "MahaDasha": maha_planet,
                "AntarDasha": antar_planet,
                "Start": antar_start.strftime("%Y-%m-%d"),
                "End": antar_end.strftime("%Y-%m-%d"),
            })
            antar_start = antar_end

    return dasha_data

def get_astrological_data(year, month, day, hour, minute, second, lat, lon, tz=DEFAULT_TIMEZONE):
    """
    Generate chart data and return full computed objects for planets, houses, and panchang.
    """
    vh = VedicHoroscopeData(
        year=year, month=month, day=day,
        hour=hour, minute=minute, second=second,
        latitude=lat, longitude=lon, tz=tz
    )
    chart = vh.generate_chart()

    houses_data = vh.get_houses_data_from_chart(chart)
    planets_data = vh.get_planets_data_from_chart(chart)
    
    # Cusps data is often associated with houses in Vedic systems,
    # but vedicastro library might provide explicit cusp data if available.
    # For now, we'll extract house signs, which implicitly define cusps in North Indian style.
    #cusps_raw = vh.get_cusps_data_from_chart(chart) 
    
    cusps_data = []
    for h in houses_data:
        cusp_nr = getattr(h, 'HouseNr', 'N/A')
        cusp_sign_name = getattr(h, 'Rasi', 'N/A') # Use 'Rasi' for the sign name

        # Attempt to get the numerical longitude of the cusp
        # Common attributes in vedicastro for degrees are 'Longitude', 'LonDecDeg', 'Degree'
        cusp_lon_deg = getattr(h, 'Longitude', None)
        if cusp_lon_deg is None:
            cusp_lon_deg = getattr(h, 'LonDecDeg', None)
        if cusp_lon_deg is None:
            cusp_lon_deg = getattr(h, 'Degree', None)
        
        # Also try to get a pre-formatted DMS string if available
        # Common attributes are 'DMS', 'SignLonDMS'
        cusp_dms_string = getattr(h, 'DMS', None)
        if cusp_dms_string is None:
            cusp_dms_string = getattr(h, 'SignLonDMS', None)


        # Validate cusp_lon_deg type
        if not isinstance(cusp_lon_deg, (int, float)):
             # If it's not a number, it's invalid for calculations
             print(f"Warning: Cusp {cusp_nr} longitude is not a valid number ({cusp_lon_deg}). Treating as unavailable.")
             cusp_lon_deg = None # Set to None to trigger fallback


        if cusp_lon_deg is not None:
            # If we have a valid numeric longitude, calculate lords
            rl_data = vh.get_rl_nl_sl_data(deg=cusp_lon_deg)
            
            # If no specific DMS string was found, create one from the degree
            if cusp_dms_string is None:
                # Basic DMS construction (SignDegree-Minute-Second)
                # This assumes cusp_lon_deg is absolute longitude.
                # If 'h' provides degree *within* its Rasi, adjust logic.
                deg_in_sign = cusp_lon_deg % 30 # Degrees within current sign
                minutes = (deg_in_sign - int(deg_in_sign)) * 60
                seconds = (minutes - int(minutes)) * 60
                cusp_dms_string = f"{int(deg_in_sign):02d}°{int(minutes):02d}'{int(seconds):02d}\""
            
            cusps_data.append({
                "CuspNr": cusp_nr,
                "Sign": cusp_sign_name, # Storing the Rasi name here
                "LonDecDeg": cusp_lon_deg, # Storing the numeric degree
                "SignLonDMS": cusp_dms_string, # Storing the formatted string
                "SignLord": rl_data.get("RasiLord", "Unknown"),
                "NakshatraLord": rl_data.get("NakshatraLord", "Unknown"),
                "SubLord": rl_data.get("SubLord", "Unknown"),
            })
        else:
            # Fallback if no valid numeric longitude was found
            cusps_data.append({
                "CuspNr": cusp_nr,
                "Sign": cusp_sign_name,
                "LonDecDeg": "N/A",
                "SignLonDMS": "N/A",
                "SignLord": "N/A",
                "NakshatraLord": "N/A",
                "SubLord": "N/A",
            })


    house_signs = {h.HouseNr: ZODIAC_MAP.get(h.Rasi, 0) for h in houses_data}

    house_planets = collections.defaultdict(list)
    for p in planets_data:
        house_planets[p.HouseNr].append(p.Object)

    return vh, chart, house_signs, house_planets, planets_data, cusps_data
 # Also return 'chart'
                                                                           # as it's needed by get_panchang_details

def get_panchang_details(vh_obj, chart_obj, moon_data, sun_data):
    """
    Extracts and formats Panchanga details.
    """
    details_lines = []

    if moon_data:
        details_lines.append(f"Moon Sign: {moon_data.Rasi}")
        rl_data = vh_obj.get_rl_nl_sl_data(deg=moon_data.LonDecDeg)
        nak = rl_data.get("Nakshatra", getattr(moon_data, "Nakshatra", "Unknown"))
        pada = rl_data.get("Pada", None)
        naklord = rl_data.get("NakshatraLord", None)
        sublord = rl_data.get("SubLord", None)
        details_lines.append(f"Nakshatra: {nak}" + (f" (Pada {pada})" if pada else ""))
        if naklord: details_lines.append(f"Nakshatra Lord: {naklord}")
        if sublord: details_lines.append(f"Sub Lord: {sublord}")
    else:
        details_lines.append("Moon Sign: Not available")
        nak = "Unknown" # For Varna/Vasya/Yoni below

    # --- Tithi Calculation ---
    if moon_data and sun_data:
        diff = (moon_data.LonDecDeg - sun_data.LonDecDeg) % 360
        tithi_num = int(diff // 12) + 1
        paksha = "Shukla" if tithi_num <= 15 else "Krishna"
        tname = TITHI_NAMES[(tithi_num - 1) % 15]
        details_lines.append(f"Tithi: {tithi_num} - {tname} ({paksha} Paksha)")
    else:
        details_lines.append("Tithi: N/A (Moon or Sun data missing)")

    # --- Karana ---
    karana_name = "Unknown"
    try:
        if hasattr(chart_obj, 'Panchang') and \
           hasattr(chart_obj.Panchang, 'Karana') and \
           hasattr(chart_obj.Panchang.Karana, 'Name'):
            karana_name = chart_obj.Panchang.Karana.Name
        elif moon_data and sun_data: # Fallback calculation if vedicastro doesn't provide
            diff = (moon_data.LonDecDeg - sun_data.LonDecDeg + 360) % 360
            karana_num = int(diff // 6) + 1
            # There are 11 fixed and 4 movable karanas. This is a simplification.
            # Real Karana calculation is more complex with cycling.
            karana_name = KARANA_NAMES[(karana_num - 1) % len(KARANA_NAMES)] if KARANA_NAMES else f"Karana #{karana_num} (Approx.)"
    except Exception as karana_e:
        print(f"Warning: Could not get Karana from chart object: {karana_e}")
        if moon_data and sun_data:
            diff = (moon_data.LonDecDeg - sun_data.LonDecDeg + 360) % 360
            karana_num = int(diff // 6) + 1
            karana_name = KARANA_NAMES[(karana_num - 1) % len(KARANA_NAMES)] if KARANA_NAMES else f"Karana #{karana_num} (Approx.)"
        else:
            karana_name = "N/A"
    details_lines.append(f"Karana: {karana_name}")

    # --- Yoga ---
    if moon_data and sun_data:
        sum_lon = (moon_data.LonDecDeg + sun_data.LonDecDeg) % 360
        yoga_index = int(sum_lon // (360 / 27))
        yoga_name = YOGA_NAMES[yoga_index] if yoga_index < len(YOGA_NAMES) else "Unknown"
        details_lines.append(f"Yoga: {yoga_name} (#{yoga_index + 1}, Sum {sum_lon:.2f}°)")
    else:
        details_lines.append("Yoga: N/A (Moon or Sun data missing)")

    # --- Varna / Vasya / Yoni Mapping ---
    varna = VARNA_MAP.get(nak, "Unknown")
    vasya = VASYA_MAP.get(moon_data.Rasi, "Unknown") if moon_data else "Unknown"
    yoni = YONI_MAP.get(nak, "Unknown")

    details_lines.append(f"Varna: {varna}")
    details_lines.append(f"Vasya: {vasya}")
    details_lines.append(f"Yoni: {yoni}")

    return "\n".join(details_lines)