# astro_app_ui.py

import sys, os
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from geopy.geocoders import Nominatim
from datetime import datetime

# Import modules
from astro_calculations import get_astrological_data, compute_vimshottari_dasha, get_panchang_details
from chart_renderer import draw_north_chart
from config import DEFAULT_TIMEZONE

class AstrologyApp:
    def __init__(self, master):
        self.master = master
        master.title("Vedic Astrology Chart Generator")
        
        # Configure grid weights for responsive resizing
        master.grid_rowconfigure(0, weight=1)
        master.grid_columnconfigure(1, weight=1) # Chart column
        master.grid_columnconfigure(2, weight=1) # Notebook column

        # --- Input Frame ---
        self.frame_input = ttk.Frame(master, padding="10")
        self.frame_input.grid(row=0, column=0, sticky="nsew")
        self.frame_input.grid_columnconfigure(1, weight=1) # Allow entry fields to expand

        # Place entry
        ttk.Label(self.frame_input, text="Place:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        self.place_entry = ttk.Entry(self.frame_input, width=30) # Increased width
        self.place_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=2)

        self.search_btn = ttk.Button(self.frame_input, text="Search", command=self.search_place)
        self.search_btn.grid(row=0, column=2, padx=5, pady=2)

        # Latitude / Longitude (disabled)
        ttk.Label(self.frame_input, text="Latitude:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        self.lat_var = tk.StringVar()
        self.lat_entry = ttk.Entry(self.frame_input, textvariable=self.lat_var, state="readonly", width=30)
        self.lat_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)

        ttk.Label(self.frame_input, text="Longitude:").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        self.lon_var = tk.StringVar()
        self.lon_entry = ttk.Entry(self.frame_input, textvariable=self.lon_var, state="readonly", width=30)
        self.lon_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=2)

        # Date
        ttk.Label(self.frame_input, text="Date (YYYY-MM-DD):").grid(row=3, column=0, sticky="w", padx=5, pady=2)
        self.date_entry = ttk.Entry(self.frame_input, width=30)
        self.date_entry.grid(row=3, column=1, sticky="ew", padx=5, pady=2)
        self.date_entry.insert(0, datetime.now().strftime("%Y-%m-%d")) # Default to today

        # Time (HH:MM:SS) using Comboboxes
        ttk.Label(self.frame_input, text="Time (HH:MM:SS):").grid(row=4, column=0, sticky="w", padx=5, pady=2)
        
        time_combos_frame = ttk.Frame(self.frame_input) # Use self.frame_input
        time_combos_frame.grid(row=4, column=1, sticky="w", padx=5, pady=2)

        self.hour_var = tk.StringVar(value=datetime.now().strftime("%H"))
        self.hour_combo = ttk.Combobox(time_combos_frame, textvariable=self.hour_var,
                                       values=[f"{i:02d}" for i in range(24)],
                                       width=3, state="readonly")
        self.hour_combo.pack(side="left")
        self.hour_combo.bind("<<ComboboxSelected>>", self._on_time_change)

        self.minute_var = tk.StringVar(value=datetime.now().strftime("%M"))
        self.minute_combo = ttk.Combobox(time_combos_frame, textvariable=self.minute_var,
                                         values=[f"{i:02d}" for i in range(60)],
                                         width=3, state="readonly")
        self.minute_combo.pack(side="left", padx=2)
        self.minute_combo.bind("<<ComboboxSelected>>", self._on_time_change)

        self.second_var = tk.StringVar(value="00")
        self.second_combo = ttk.Combobox(time_combos_frame, textvariable=self.second_var,
                                         values=[f"{i:02d}" for i in range(60)],
                                         width=3, state="readonly")
        self.second_combo.pack(side="left")
        self.second_combo.bind("<<ComboboxSelected>>", self._on_time_change)

        # Buttons
        button_frame = ttk.Frame(self.frame_input)
        button_frame.grid(row=5, column=0, columnspan=3, pady=10)

        self.update_btn = ttk.Button(button_frame, text="Update Chart", command=self.update_chart)
        self.update_btn.pack(side="left", padx=5)

        self.clear_btn = ttk.Button(button_frame, text="Clear", command=self.clear_fields)
        self.clear_btn.pack(side="left", padx=5)

        self.close_btn = ttk.Button(button_frame, text="Close", command=master.destroy)
        self.close_btn.pack(side="left", padx=5)
        master.protocol("WM_DELETE_WINDOW", master.destroy)

        # --- Chart Canvas ---
        self.fig, self.ax = plt.subplots(figsize=(6, 6))
        self.canvas = FigureCanvasTkAgg(self.fig, master=master)
        self.canvas.get_tk_widget().grid(row=0, column=1, rowspan=7, sticky="nsew", padx=5, pady=5)

        toolbar = NavigationToolbar2Tk(self.canvas, master, pack_toolbar=False)
        toolbar.grid(row=7, column=1, sticky="ew")

        # --- Right side Notebook ---
        notebook = ttk.Notebook(master)
        notebook.grid(row=0, column=2, rowspan=8, sticky="nsew", padx=5, pady=5)

        # Tab1: Details
        self.tab1 = ttk.Frame(notebook)
        notebook.add(self.tab1, text="Details")
        self.details_text = tk.Text(self.tab1, width=40, height=15, state="disabled", wrap="word")
        self.details_text.pack(fill="both", expand=True, padx=5, pady=5)

        # Tab2: Planets
        self.tab2 = ttk.Frame(notebook)
        notebook.add(self.tab2, text="Planets")
        self.planets_tree = ttk.Treeview(self.tab2, columns=("Planet","Sign","DMS","SignLord","StarLord","SubLord"), show="headings")
        for col in self.planets_tree["columns"]:
            self.planets_tree.heading(col, text=col)
            self.planets_tree.column(col, width=80)
        self.planets_tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Tab3: Dasha
        self.tab3 = ttk.Frame(notebook)
        notebook.add(self.tab3, text="Dasha")
        self.dasha_tree = ttk.Treeview(self.tab3, columns=("Maha Dasha", "Antar Dasha", "Start", "End"), show="headings")
        self.dasha_tree.heading("Maha Dasha", text="Maha Dasha")
        self.dasha_tree.heading("Antar Dasha", text="Antar Dasha")
        self.dasha_tree.heading("Start", text="Start")
        self.dasha_tree.heading("End", text="End")
        self.dasha_tree.column("Maha Dasha", width=90)
        self.dasha_tree.column("Antar Dasha", width=90)
        self.dasha_tree.column("Start", width=90)
        self.dasha_tree.column("End", width=90)
        self.dasha_tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Tab4: Cusps
        self.tab4 = ttk.Frame(notebook)
        notebook.add(self.tab4, text="Cusps")
        self.cusps_tree = ttk.Treeview(self.tab4, columns=("Cusp","Sign","DMS","SignLord","StarLord","SubLord"), show="headings")
        for col in self.cusps_tree["columns"]:
            self.cusps_tree.heading(col, text=col)
            self.cusps_tree.column(col, width=80)
        self.cusps_tree.pack(fill="both", expand=True, padx=5, pady=5)

    # --- Place Search ---
    def search_place(self):
        try:
            geolocator = Nominatim(user_agent="astro_app_v1") # Use a unique user_agent
            location = geolocator.geocode(self.place_entry.get())
            if location:
                self.lat_var.set(f"{location.latitude:.4f}")
                self.lon_var.set(f"{location.longitude:.4f}")
            else:
                messagebox.showerror("Error", "Place not found.")
        except Exception as e:
            messagebox.showerror("Error", f"Geolocation service error: {e}")
        
    def _on_time_change(self, event=None):
        """Called when a time combobox selection changes, triggers chart update."""
        self.update_chart()

    # --- Update Chart ---
    def update_chart(self):
        try:
            place = self.place_entry.get().strip()
            lat_str = self.lat_var.get().strip()
            lon_str = self.lon_var.get().strip()
            date_str = self.date_entry.get().strip()
            hour_str = self.hour_var.get().strip()
            minute_str = self.minute_var.get().strip()
            second_str = self.second_var.get().strip()

            if not all([place, lat_str, lon_str, date_str, hour_str, minute_str, second_str]):
                messagebox.showwarning("Input Error", "Please fill all birth details.")
                return

            lat = float(lat_str)
            lon = float(lon_str)
            year, month, day = map(int, date_str.split("-"))
            hour = int(hour_str)
            minute = int(minute_str)
            second = int(second_str)
            
            # Reconstruct time_str for display purposes only
            display_time_str = f"{hour:02d}:{minute:02d}:{second:02d}"
            display_date_str = f"{day:02d}-{month:02d}-{year}"

            # --- Generate chart data using astro_calculations ---
            vh_obj, chart_obj, house_signs, house_planets, planets_data, cusps_data = get_astrological_data(
                year, month, day, hour, minute, second, lat, lon, tz=DEFAULT_TIMEZONE
            )

            # --- Draw chart ---
            draw_north_chart(
                self.ax, house_signs, house_planets,
                place, lat, lon,
                date_str=display_date_str,
                time_str=display_time_str,
                planets_data=planets_data
            )
            self.canvas.draw_idle()

            # --- TAB 1 : Panchanga / Moon Details ---
            moon = next((p for p in planets_data if p.Object == "Moon"), None)
            sun = next((p for p in planets_data if p.Object == "Sun"), None)
            
            details_content = get_panchang_details(vh_obj, chart_obj, moon, sun)

            self.details_text.config(state="normal")
            self.details_text.delete("1.0", tk.END)
            self.details_text.insert(tk.END, details_content)
            self.details_text.config(state="disabled")

            # --- TAB 2: Planets ---
            for i in self.planets_tree.get_children():
                self.planets_tree.delete(i)
            for p in planets_data:
                name = p.Object + ("R" if getattr(p, "isRetroGrade", False) else "") # Corrected attribute name
                # Safely get DMS string, default to formatted degree if not available
                dms_str = getattr(p, "SignLonDMS", None) 
                if dms_str is None and hasattr(p, "LonDecDeg"):
                    dms_str = f"{int(p.LonDecDeg // 30) + 1}-{int(p.LonDecDeg % 30):.0f}-{int((p.LonDecDeg % 1) * 60):.0f}'" # Crude DMS
                
                self.planets_tree.insert(
                    "", "end",
                    values=(name, p.Rasi, dms_str,
                            getattr(p, "RasiLord", "Unknown"),
                            getattr(p, "NakshatraLord", "Unknown"),
                            getattr(p, "SubLord", "Unknown"))
                )
            
            # --- TAB 3: Dasha ---
            for i in self.dasha_tree.get_children():
               self.dasha_tree.delete(i)

            if moon:
                moon_lon = moon.LonDecDeg
                dasha_data = compute_vimshottari_dasha(moon_lon, date_str)

                # Group Antardashas under their Maha Dashas
                grouped_dashas = {} # Use dict for grouping for cleaner logic
                maha_dasha_order = [] # To preserve the order of Maha Dashas

                for d in dasha_data:
                    maha_planet = d["MahaDasha"]
                    if maha_planet not in grouped_dashas:
                        grouped_dashas[maha_planet] = []
                        maha_dasha_order.append(maha_planet)
                    grouped_dashas[maha_planet].append(d)

                for maha_planet in maha_dasha_order:
                    antardashas_for_maha = grouped_dashas[maha_planet]
                    
                    if not antardashas_for_maha:
                        continue
         
                    maha_start = antardashas_for_maha[0]["Start"]
                    maha_end = antardashas_for_maha[-1]["End"]

                    maha_id = self.dasha_tree.insert(
                        "", "end",
                        text=maha_planet,
                        values=(maha_planet, "", maha_start, maha_end),
                        open=False # Start collapsed
                    )

                    for antar_dasha_item in antardashas_for_maha:
                        self.dasha_tree.insert(
                            maha_id, "end",
                            values=("", antar_dasha_item["AntarDasha"], antar_dasha_item["Start"], antar_dasha_item["End"])
                        )
            else:
                self.dasha_tree.insert("", "end", values=("Moon data not found for Dasha", "", "", ""))
            
            # --- TAB 4: Cusps ---
            for i in self.cusps_tree.get_children():
                self.cusps_tree.delete(i)
            
            # Note: The original cusps_data structure was minimal.
            # You might need to enhance astro_calculations.py to provide more detailed cusp info
            # (e.g., getting SignLord, StarLord, SubLord for each cusp if available from vedicastro).
            # For now, we'll populate with available data.
            for c in cusps_data:
                # To get SignLord, StarLord, SubLord for cusps, you'd typically need to
                # call vh_obj.get_rl_nl_sl_data(deg=c["LonDecDeg"]) for each cusp.
                # Adding placeholder "N/A" for now.
                #dms_display = c.get('SignLonDMS', 'N/A')
                #rasi_display = c.get('Sign', 'N/A')
                self.cusps_tree.insert(
                    "", "end",
                    values=(f"Cusp {c['CuspNr']}", c["Sign"], c["SignLonDMS"],
                            c["SignLord"], c["NakshatraLord"], c["SubLord"])
                )
                  
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update chart:\n{e}")

    # --- Clear ---
    def clear_fields(self):
        self.place_entry.delete(0, tk.END)
        self.lat_var.set("")
        self.lon_var.set("")
        self.date_entry.delete(0, tk.END)
        
        # Clear time comboboxes and set to default "00"
        self.hour_var.set("00")
        self.minute_var.set("00")
        self.second_var.set("00")
        
        self.ax.clear()
        self.canvas.draw_idle()
        self.details_text.config(state="normal")
        self.details_text.delete("1.0", tk.END)
        self.details_text.config(state="disabled")
        for tree in [self.planets_tree, self.dasha_tree, self.cusps_tree]:
            for i in tree.get_children():
                tree.delete(i)    