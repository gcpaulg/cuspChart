# main.py

import tkinter as tk
from astro_app_ui import AstrologyApp

if __name__ == "__main__":
    root = tk.Tk()
    app = AstrologyApp(root)
    
    def on_closing():
        root.quit()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()