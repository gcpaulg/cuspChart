# config.py

import collections
from datetime import datetime

# Default Timezone for calculations
DEFAULT_TIMEZONE = "Asia/Kolkata"

# Planet Abbreviations for chart display
PLANET_ABBREVIATIONS = {
    "Sun": "Su", "Moon": "Mo", "Mars": "Ma", "Mercury": "Me",
    "Jupiter": "Ju", "Venus": "Ve", "Saturn": "Sa",
    "Rahu": "Ra", "Ketu": "Ke"
}

# Zodiac Map for house signs
ZODIAC_MAP = {
    "Aries": 1, "Taurus": 2, "Gemini": 3, "Cancer": 4,
    "Leo": 5, "Virgo": 6, "Libra": 7, "Scorpio": 8,
    "Sagittarius": 9, "Capricorn": 10, "Aquarius": 11, "Pisces": 12
}

# Dasha sequence (Planet, Years)
VIMSHOTTARI_DASHAS = [
    ("Ketu", 7), ("Venus", 20), ("Sun", 6), ("Moon", 10),
    ("Mars", 7), ("Rahu", 18), ("Jupiter", 16), ("Saturn", 19), ("Mercury", 17)
]

# Tithi Names
TITHI_NAMES = [
    "Pratipada", "Dvitiya", "Tritiya", "Chaturthi", "Panchami", "Shashthi",
    "Saptami", "Ashtami", "Navami", "Dashami", "Ekadashi", "Dwadashi",
    "Trayodashi", "Chaturdashi", "Purnima/Amavasya"
]

# Karana Names
KARANA_NAMES = [
    "Bava","Balava","Kaulava","Taitila","Garaja","Vanija","Vishti(Bhadra)",
    "Shakuni", "Chatushpada", "Nagava","Kimstughna" # Note: There are 11 "fixed" Karanas used cyclically, + 4 "movable" ones
]

# Yoga Names
YOGA_NAMES = [
    "Vishkambha", "Priti", "Ayushman", "Saubhagya", "Shobhana", "Atiganda",
    "Sukarma", "Dhriti", "Shoola", "Ganda", "Vriddhi", "Dhruva",
    "Vyaghata", "Harshana", "Vajra", "Siddhi", "Vyatipata", "Variyan",
    "Parigha", "Shiva", "Siddha", "Sadhya", "Shubha", "Shukla",
    "Brahma", "Indra", "Vaidhriti"
]

# Nakshatra Mappings for Varna, Vasya, Yoni
VARNA_MAP = {
    "Ashwini": "Kshatriya", "Bharani": "Shudra", "Krittika": "Brahmana", "Rohini": "Vaishya",
    "Mrigashira": "Vaishya", "Ardra": "Shudra", "Punarvasu": "Kshatriya", "Pushya": "Brahmana",
    "Ashlesha": "Brahmana", "Magha": "Kshatriya", "Purva Phalguni": "Vaishya",
    "Uttara Phalguni": "Kshatriya", "Hasta": "Vaishya", "Chitra": "Shudra",
    "Swati": "Vaishya", "Vishakha": "Kshatriya", "Anuradha": "Shudra",
    "Jyeshtha": "Brahmana", "Mula": "Shudra", "Purva Ashadha": "Kshatriya",
    "Uttara Ashadha": "Vaishya", "Shravana": "Brahmana", "Dhanishta": "Vaishya",
    "Shatabhisha": "Shudra", "Purva Bhadrapada": "Brahmana", "Uttara Bhadrapada": "Kshatriya",
    "Revati": "Vaishya"
}

VASYA_MAP = {
    "Aries": "Human", "Taurus": "Cattle", "Gemini": "Human", "Cancer": "Wild Animal",
    "Leo": "Quadruped", "Virgo": "Human", "Libra": "Quadruped",
    "Scorpio": "Insect", "Sagittarius": "Human", "Capricorn": "Quadruped",
    "Aquarius": "Human", "Pisces": "Water Creature"
}

YONI_MAP = {
    "Ashwini": "Horse", "Bharani": "Elephant", "Krittika": "Sheep", "Rohini": "Serpent",
    "Mrigashira": "Serpent", "Ardra": "Dog", "Punarvasu": "Cat", "Pushya": "Sheep",
    "Ashlesha": "Cat", "Magha": "Rat", "Purva Phalguni": "Rat", "Uttara Phalguni": "Cow",
    "Hasta": "Buffalo", "Chitra": "Tiger", "Swati": "Buffalo", "Vishakha": "Tiger",
    "Anuradha": "Deer", "Jyeshtha": "Deer", "Mula": "Dog", "Purva Ashadha": "Monkey",
    "Uttara Ashadha": "Mongoose", "Shravana": "Monkey", "Dhanishta": "Lion",
    "Shatabhisha": "Horse", "Purva Bhadrapada": "Lion", "Uttara Bhadrapada": "Cow",
    "Revati": "Elephant"
}