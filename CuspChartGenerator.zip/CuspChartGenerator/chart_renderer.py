# chart_renderer.py

import matplotlib.pyplot as plt
import numpy as np
from config import PLANET_ABBREVIATIONS

def draw_north_chart(ax, house_signs, house_planets, place, latitude, longitude, date_str, time_str, planets_data=None):
    """
    Draws a North Indian style astrological chart on the given Matplotlib axes.
    """
    ax.clear()
    ax.set_aspect('equal')
    ax.axis('off')

    a = 5
    # Outer square
    square = np.array([[-a, -a], [a, -a], [a, a], [-a, a], [-a, -a]])
    ax.plot(*zip(*square), color="black")

    # Diagonals & inner diamond
    ax.plot([-a, a], [-a, a], color="red")
    ax.plot([-a, a], [a, -a], color="red")
    ax.plot([0, a], [a, 0], color="black")
    ax.plot([a, 0], [0, -a], color="black")
    ax.plot([0, -a], [-a, 0], color="black")
    ax.plot([-a, 0], [0, a], color="black")

    # House number positions (your working coords) - these represent the signs in each house
    house_coords = {
        1:  (0, a*0.10), # Center of Ascendant house
        2:  (-a*0.50, a*0.60),
        3:  (-a*0.60, a*0.50), # Adjusted from NIC.txt for better spacing
        4:  (-a*0.10, -a*0.00),
        5:  (-a*0.60, -a*0.50), # Adjusted from NIC.txt
        6:  (-a*0.50, -a*0.60),
        7:  (0, -a*0.10),
        8:  (a*0.50, -a*0.60),
        9:  (a*0.60, -a*0.50), # Adjusted from NIC.txt
        10: (a*0.10, 0),
        11: (a*0.60, a*0.50), # Adjusted from NIC.txt
        12: (a*0.50, a*0.60),
    }

    # Planet coordinates (midpoints) - adjusted to be slightly outside house_coords for clarity
    planet_coords = {
        1:  (0, a*0.55), # Above ascendant house
        2:  (-a*0.55, a*0.80),
        3:  (-a*0.80, a*0.55),
        4:  (-a*0.55, -a*0.00),
        5:  (-a*0.80, -a*0.55),
        6:  (-a*0.55, -a*0.80),
        7:  (0, -a*0.55),
        8:  (a*0.55, -a*0.80),
        9:  (a*0.80, -a*0.55),
        10: (a*0.55, 0),
        11: (a*0.80, a*0.55),
        12: (a*0.55, a*0.80),
    }

    # Draw sign labels / numbers
    for house, (x, y) in house_coords.items():
        sign = house_signs.get(house, "")
        ax.text(x, y, str(sign), ha="center", va="center",
                fontsize=10, color="black", weight="bold")

    # build retrograde map if planets_data provided
    retro_map = {}
    if planets_data:
        for p in planets_data:
            # vedicastro uses 'isRetroGrade' attribute, not 'Retrograde'
            retro_map[p.Object] = bool(getattr(p, "isRetroGrade", False))

    # Draw planets with simple stacking and retrograde 'R'
    for house, (px, py) in planet_coords.items():
        planets = house_planets.get(house, [])
        for i, planet in enumerate(planets):
            short_name = PLANET_ABBREVIATIONS.get(planet, planet[:2])
            if retro_map.get(planet, False):
                short_name += "R"
            
            # Simple stacking: adjust text position slightly for multiple planets
            # This ensures planets don't completely overlap for clarity.
            dx = (i % 2) * 0.75 - 0.35 # Offset horizontally
            dy = -(i // 2) * 0.35     # Offset vertically
            
            ax.text(px + dx, py + dy, short_name, ha="center", va="center",
                    fontsize=10, color="blue") # Reduced font size for better fit

    # Title
    title_text = f"Cusp Chart:{place}\nLat: {latitude:.4f}, Lon: {longitude:.4f}\nDate: {date_str}, Time: {time_str}"
    ax.text(0, a * 1.05, title_text, ha="center", va="bottom",
            fontsize=10, color="black", weight="bold")

    ax.figure.canvas.draw_idle()